//
//  RecipeDetailsViewController.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

import UIKit

class RecipeDetailsViewController: UIViewController {
    private var recipe: Recipe
    private let token: String

    private let nameField = UITextField()
    private let ingredientsField = UITextField()
    private let updateButton = UIButton(type: .system)

    init(recipe: Recipe, token: String) {
        self.recipe = recipe
        self.token = token
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Recipe Details"
        setupUI()
    }

    private func setupUI() {
        nameField.text = recipe.recipeName
        ingredientsField.text = recipe.ingredients.joined(separator: ", ")
        updateButton.setTitle("Update Recipe", for: .normal)

        updateButton.addTarget(self, action: #selector(handleUpdate), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [nameField, ingredientsField, updateButton])
        stack.axis = .vertical
        stack.spacing = 16

        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8)
        ])
    }

    @objc private func handleUpdate() {
        recipe.recipeName = nameField.text ?? recipe.recipeName
        recipe.ingredients = ingredientsField.text?.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) } ?? recipe.ingredients

        APIService.shared.updateRecipe(recipe: recipe, token: token) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let updatedRecipe):
                    print("Recipe updated: \(updatedRecipe)")
                    self?.navigationController?.popViewController(animated: true)
                case .failure(let error):
                    print("Error updating recipe: \(error)")
                }
            }
        }
    }
}

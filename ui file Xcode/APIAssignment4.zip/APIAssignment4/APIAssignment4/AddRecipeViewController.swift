//
//  AddRecipeViewController.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

import UIKit

class AddRecipeViewController: UIViewController {
    private let nameField = UITextField()
    private let ingredientsField = UITextField()
    private let addButton = UIButton(type: .system)
    private let token: String

    init(token: String) {
        self.token = token
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Add Recipe"
        setupUI()
    }

    private func setupUI() {
        nameField.placeholder = "Recipe Name"
        ingredientsField.placeholder = "Ingredients (comma-separated)"
        addButton.setTitle("Add Recipe", for: .normal)

        addButton.addTarget(self, action: #selector(handleAdd), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [nameField, ingredientsField, addButton])
        stack.axis = .vertical
        stack.spacing = 16

        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8)
        ])
    }

    @objc private func handleAdd() {
        guard let name = nameField.text, !name.isEmpty,
              let ingredientsText = ingredientsField.text, !ingredientsText.isEmpty else { return }

        let recipe = Recipe(
            id: UUID().uuidString,
            recipeName: name,
            ingredients: ingredientsText.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) },
            cookingTime: "30 mins",
            difficulty: "Easy",
            cuisine: "General",
            description: "Description here",
            photoLink: "",
            averageRating: 4.5
        )

        APIService.shared.addRecipe(recipe: recipe, token: token) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let newRecipe):
                    print("Recipe added: \(newRecipe)")
                    self?.navigationController?.popViewController(animated: true)
                case .failure(let error):
                    print("Error adding recipe: \(error)")
                }
            }
        }
    }
}

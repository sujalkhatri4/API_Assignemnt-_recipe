//
//  User.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

import Foundation

struct User: Codable {
    let username: String
    let email: String
    let token: String?
}

//
//  Recipe.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

struct Recipe: Codable {
    var id: String
    var recipeName: String
    var ingredients: [String]
    var cookingTime: String
    var difficulty: String
    var cuisine: String
    var description: String
    var photoLink: String
    var averageRating: Double
}

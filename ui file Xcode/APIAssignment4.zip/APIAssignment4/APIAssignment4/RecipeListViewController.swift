//
//  RecipeListViewController.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

import UIKit

class RecipeListViewController: UIViewController {
    private let tableView = UITableView()
    private var recipes: [Recipe] = []
    private let token: String

    init(token: String) {
        self.token = token
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Recipes"
        setupTableView()
        fetchRecipes()
    }

    private func setupTableView() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leftAnchor.constraint(equalTo: view.leftAnchor),
            tableView.rightAnchor.constraint(equalTo: view.rightAnchor)
        ])
    }

    private func fetchRecipes() {
        APIService.shared.fetchRecipes(token: token) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let recipes):
                    self?.recipes = recipes
                    self?.tableView.reloadData()
                case .failure(let error):
                    print("Error fetching recipes: \(error)")
                }
            }
        }
    }

    @objc private func addRecipe() {
        let addVC = AddRecipeViewController(token: token)
        navigationController?.pushViewController(addVC, animated: true)
    }
}

extension RecipeListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        recipes.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = recipes[indexPath.row].recipeName
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let recipe = recipes[indexPath.row]
        let detailVC = RecipeDetailsViewController(recipe: recipe, token: token)
        navigationController?.pushViewController(detailVC, animated: true)
    }
}

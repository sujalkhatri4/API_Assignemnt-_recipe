    //
    //  APIAssignment4App.swift
    //  APIAssignment4
    //
    //  Created by Sujal khatri on 2024-12-08.
    //

import SwiftUI

@main
struct APIAssignment4App: App {
    var body: some Scene {
        WindowGroup {
            LoginViewControllerRepresentable()
        }
    }
}

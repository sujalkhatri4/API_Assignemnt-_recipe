import Foundation

enum APIError: Error {
    case invalidURL
    case noData
    case decodingError
    case unknownError
}

class APIService {
    static let shared = APIService()
    private let baseURL = "http://localhost:3008"
    
    func login(email: String, password: String, completion: @escaping (Result<User, Error>) -> Void) {
        let url = URL(string: "\(baseURL)/user/login")!
        performRequest(url: url, method: "POST", body: ["email": email, "password": password], completion: completion)
    }
    
    func register(username: String, email: String, password: String, completion: @escaping (Result<User, Error>) -> Void) {
        let url = URL(string: "\(baseURL)/user/register")!
        performRequest(url: url, method: "POST", body: ["username": username, "email": email, "password": password], completion: completion)
    }
    
    func fetchRecipes(token: String, completion: @escaping (Result<[Recipe], Error>) -> Void) {
        let url = URL(string: "\(baseURL)/recipe")!
        performRequest(url: url, method: "GET", token: token, completion: completion)
    }
    
    func addRecipe(recipe: Recipe, token: String, completion: @escaping (Result<Recipe, Error>) -> Void) {
        let url = URL(string: "\(baseURL)/recipe")!
        let body: [String: Any] = [
            "recipeName": recipe.recipeName,
            "ingredients": recipe.ingredients,
            "cookingTime": recipe.cookingTime,
            "difficulty": recipe.difficulty,
            "cuisine": recipe.cuisine,
            "description": recipe.description,
            "photoLink": recipe.photoLink,
            "averageRating": recipe.averageRating
        ]
        performRequest(url: url, method: "POST", body: body, token: token, completion: completion)
    }
    
    func updateRecipe(recipe: Recipe, token: String, completion: @escaping (Result<Recipe, Error>) -> Void) {
        let url = URL(string: "\(baseURL)/recipe/\(recipe.id)")!
        let body: [String: Any] = [
            "recipeName": recipe.recipeName,
            "ingredients": recipe.ingredients,
            "cookingTime": recipe.cookingTime,
            "difficulty": recipe.difficulty,
            "cuisine": recipe.cuisine,
            "description": recipe.description,
            "photoLink": recipe.photoLink,
            "averageRating": recipe.averageRating
        ]
        performRequest(url: url, method: "PUT", body: body, token: token, completion: completion)
    }
    
    func deleteRecipe(id: String, token: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        let url = URL(string: "\(baseURL)/recipe/\(id)")!
        performRequest(url: url, method: "DELETE", token: token) { (result: Result<Data?, Error>) in
            switch result {
            case .success:
                completion(.success(true)) // Successfully deleted
            case .failure(let error):
                completion(.failure(error)) // Handle error
            }
        }
    }
    
    private func performRequest<T: Decodable>(
        url: URL,
        method: String,
        body: [String: Any]? = nil,
        token: String? = nil,
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = token {
            request.setValue(token, forHTTPHeaderField: "x-access-token")
        }
        if let body = body {
            request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle errors in the request
            guard let data = data, error == nil else {
                completion(.failure(error ?? APIError.unknownError))
                return
            }
            
            // For methods like DELETE where no data is expected, we don't need to decode
            if T.self == Void.self {
                completion(.success(() as! T)) // Return success with Void type
                return
            }
            
            // Handle other cases where data is expected to be decoded
            do {
                let decoded = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decoded))
            } catch {
                completion(.failure(APIError.decodingError))
            }
        }.resume()
    }
}

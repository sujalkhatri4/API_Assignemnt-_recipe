import SwiftUI
import UIKit

struct LoginViewControllerRepresentable: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UINavigationController {
        let loginVC = LoginViewController()
        let navController = UINavigationController(rootViewController: loginVC)
        return navController
    }
    
    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
        // Here you can manage updates if necessary, but it’s not needed for this case
    }
}

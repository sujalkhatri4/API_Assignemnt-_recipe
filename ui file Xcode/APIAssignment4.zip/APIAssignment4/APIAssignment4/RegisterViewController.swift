//
//  RegisterViewController.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

import UIKit

class RegisterViewController: UIViewController {
    private let usernameField = UITextField()
    private let emailField = UITextField()
    private let passwordField = UITextField()
    private let registerButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Register"
        setupUI()
    }

    private func setupUI() {
        usernameField.placeholder = "Username"
        emailField.placeholder = "Email"
        passwordField.placeholder = "Password"
        passwordField.isSecureTextEntry = true
        registerButton.setTitle("Register", for: .normal)

        registerButton.addTarget(self, action: #selector(handleRegister), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [usernameField, emailField, passwordField, registerButton])
        stack.axis = .vertical
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8)
        ])
    }

    @objc private func handleRegister() {
        guard let username = usernameField.text, !username.isEmpty,
              let email = emailField.text, !email.isEmpty,
              let password = passwordField.text, !password.isEmpty else {
            showAlert(message: "All fields are required!")
            return
        }

        // Corrected function name and result type
        APIService.shared.register(username: username, email: email, password: password) { [weak self] (result: Result<User, Error>) in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    print("Registration successful: \(user.username)")
                    self?.showAlert(message: "Registration Successful! Please log in.") {
                        self?.navigationController?.popViewController(animated: true)
                    }
                case .failure(let error):
                    print("Error registering user: \(error)")
                    self?.showAlert(message: "Error: \(error.localizedDescription)")
                }
            }
        }
    }

    private func showAlert(message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: "Notice", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in completion?() }))
        present(alert, animated: true)
    }
}

//
//  ProfileViewController.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

import UIKit

class ProfileViewController: UIViewController {
    private let logoutButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Profile"
        setupUI()
    }

    private func setupUI() {
        logoutButton.setTitle("Logout", for: .normal)
        logoutButton.addTarget(self, action: #selector(handleLogout), for: .touchUpInside)

        logoutButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logoutButton)

        NSLayoutConstraint.activate([
            logoutButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logoutButton.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    @objc private func handleLogout() {
        navigationController?.popToRootViewController(animated: true)
    }
}

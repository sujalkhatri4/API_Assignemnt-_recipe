//
//  UserViewModel.swift
//  Assignment_4
//
//  Created by Sujal khatri on 2024-12-08.
//

import Foundation

class UserViewModel {
    var user: User? {
        didSet {
            onUserChanged?()
        }
    }
    var onUserChanged: (() -> Void)?
    var errorMessage: String?
    
    func login(email: String, password: String) {
        APIService.shared.login(email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    self?.user = user
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    func register(username: String, email: String, password: String) {
        APIService.shared.register(username: username, email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    self?.user = user
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    func logout() {
        user = nil
    }
}
